Page({
    data: {
        isLike: true,
        imgUrls: [
            //"https://desk-fd.zol-img.com.cn/t_s960x600c5/g2/M00/0C/00/ChMlWVyA5JuIJ-ifABrdMvVincoAAIp9gNZMZ0AGt1K305.jpg",
        ],
        indicatorDots: true, //是否显示面板指示点
        autoplay: true, //是否自动切换
        interval: 3000, //自动切换时间间隔,3s
        duration: 1000, //  滑动动画时长1s
        // 商品详情介绍
        detailImg: [
            //"http://www.5068.com/uploads/allimg/131129/1130355520-0.jpg",

        ],
        giftName: null,
        price: null,
        giftId: '',
        like: null,
        url: null,
        userLikeGiftId: [],
        isLike: false,
        recordDoc: '',
    },
    //预览图片

    previewImage: function(e) {
        var current = e.target.dataset.src;

        wx.previewImage({
            current: current, // 当前显示图片的http链接  
            urls: this.data.imgUrls // 需要预览的图片http链接列表  
        })
    },
    // 收藏
    addLike() {
        this.setData({
            isLike: !this.data.isLike
        });
    },
    // 跳到购物车
    toCar() {
        wx.switchTab({
            url: '/pages/cart/cart'
        })
    },
    // 立即购买
    immeBuy() {
        wx.showToast({
            title: '购买成功',
            icon: 'success',
            duration: 2000
        });
    },
    loveIt() {
        var giftid = this.data.giftId
        var islike = this.data.isLike
        //先判断数据库中是否有这个用户的记录
        var _doc = this.data.recordDoc
        var isfirst = true
        if (_doc)
            isfirst = false
        if (isfirst) {
            const db = wx.cloud.database()
            db.collection('users').add({
                data: {
                    _likeGiftId: [
                        giftid
                    ]
                },
                success: function(res) {
                    console.log("点赞成功,加入礼物ID：", giftid)
                },
                fail: console.err
            })
        } else if (!islike) {
            const db = wx.cloud.database()
            const _ = db.command
            db.collection('users').doc(_doc).update({
                data: {
                    _likeGiftId: _.push([giftid])
                },
                success: function(res) {
                    console.log("点赞成功,增加礼物ID：", giftid)
                },
                fail: console.err
            })
        }
        wx.showToast({
            title: '点赞成功',
            icon: 'success',
            duration: 2000
        });
        // wx.navigateTo({ url: `../myLove/myLove?giftId=` + this.data.giftId })
        wx.switchTab({
            url: '../myLove/myLove'
        })
    },
    goToBuy() {
        var that = this;
        wx.showModal({
            title: '请前往该页面购买！谢谢',
            content: that.data.url,
            cancelText: "再看看", //默认是“取消”
            cancelColor: 'green', //取消文字的颜色
            confirmText: "点击复制", //默认是“确定”
            confirmColor: 'red', //确定文字的颜色
            success: function(res) {
                if (res.confirm) {
                    // console.log('用户点击确定')
                    wx.setClipboardData({ //调用复制内容到剪切板
                        data: that.data.imgUrls[0],
                        success: function(res) {
                            /*wx.getClipboardData({ //调用获取剪切板内容
                              success: function (res){
                                console.log(res.data);
                              }
                            })*/
                        }
                    })
                } else if (res.cancel) {
                    console.log('用户点击取消')
                }
            }
        })
    },
    onLoad: function(query) {
        //console.log(query.id)
        var that = this;
        console.log("调用了查询函数,openid:", getApp().globalData.openid)
        const queryDb = wx.cloud.database()
        queryDb.collection('users').where({
            _openid: getApp().globalData.openid
        }).get({
            success: res => {
                that.setData({
                    userLikeGiftId: res.data[0]._likeGiftId,
                    recordDoc: res.data[0]._id,
                })
                console.log("查询成功", that.data.userLikeGiftId)
                console.log("喜欢数量", that.data.userLikeGiftId.length)
                //判断该礼物是否已经加入该用户的喜欢列表
                for (var i = 0; i < that.data.userLikeGiftId.length; i++) {
                    console.log(that.data.userLikeGiftId[i])
                    if (that.data.userLikeGiftId[i] == that.data.giftId) {
                        that.setData({
                            isLike: true
                        })
                        break
                    }
                }
                if (that.data.isLike)
                    console.log("已经点赞该商品!")
                else
                    console.log("未点赞该商品!")
            },
            fail: err => {
                console("查询失败", err)
            },
            complete: res => {
                console("查询结束", res)
            }
        })
        that.setData({
            giftId: query.id
        })

        //云开发连接数据库
        const db = wx.cloud.database({
            env: 'gift-test-2abb72' //环境ID
        })
        const wx_gift = db.collection('wx_gift')


        wx_gift.where({
                _id: that.data.giftId,
            })
            .get({
                success(res) {
                    // console.log(res.data)
                    var myjson = res.data;
                    var str = [];
                    //将json对象转换成数组对象
                    for (var one in myjson) {
                        var str = myjson[one];
                        //加到数组中去
                        that.setData({
                            // imgUrls: that.data.imgUrls.concat(str.imageUrl[], str.imageUrl[], str.imageUrl[]),
                            imgUrls: that.data.imgUrls.concat(str.imageUrl),
                            //  detailImg: that.data.detailImg.concat(str.deatailUrlOne, str.deatailUrlTwo, str.deatailUrlThree),
                            detailImg: that.data.detailImg.concat(str.deatail),
                            price: str.price,
                            giftName: str.giftName,
                            like: str.like,
                            url: str.url
                        })
                    }
                    console.log(that.data.imgUrls)
                }
            })
    }
})