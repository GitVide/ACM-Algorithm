import common from '../../common/app'
import category, { defaultItem } from '../../common/category'
const categorys = Object.keys(category).map(item => category[item])
//console.log(categorys)


const page = {
  data: {
    categorys
  }
  , onLoad() {
    console.log('礼物挑选器页面加载');
  }
  , reset() {
    this.setData({
      categorys: categorys.map(category => {
      category.selectedIndex = 0;
        return category
      })
    })
  }
  //事件处理函数
  , select(e) {
    const { item, group } = e.target.dataset
    //循环
    outer:
    for (let i = 0, li = categorys.length; i < li; ++i) {
      //遍历选择框
      let category = categorys[i]
      let { items, sqlItems, name } = category
      if (name === group) {
        for (let j = 0, lj = items.length; j < lj; ++j) {
          let data = items[j]
          if (data === item) {
            category.selectedIndex = j
            break outer;
          }
        }
      }
    }
    this.setData({ categorys })
  }

  , confirm() {
    //const queryParameter = { scene:"告白",relation:"基友",price:[0,1000], query:"第一个" }
    var queryParameter = {}
    //var queryParametertest = []
    var index = 0;
    for (const category of categorys) { 
      const { name, selectedIndex } = category
      if (index != categorys.length - 1) { //是否到达选择价格
        if (selectedIndex === 0) {
          //未限定礼物类型
          queryParameter[name] = category.sqlItems
          // queryParametertest=[];
        }
        else {
          //限定礼物类型
          queryParameter[name] = new Array(category.sqlItems[selectedIndex])
          queryParameter[name].push("null")
        }
        index++
      }
      else {
        queryParameter[name] = category.sqlItems[selectedIndex]
      }


    }
    //传参并跳转至挑选页
    // wx.navigateTo({ url: `../gift-result/gift-result?queryParameter=${JSON.stringify(queryParameter)}` })
    wx.navigateTo({ url: `../gift-result/gift-result?queryParameter=${JSON.stringify(queryParameter)}` })
  }
  , onShareAppMessage: function () {
    return {
      title: '礼物挑选神器',
      desc: '量身设计的选礼解决方案'
    }
  }
}

Object.assign(page, common)
Page(page)
