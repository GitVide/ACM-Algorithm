import common from '../../common/app'
import { handleTitle, extractPriceFromPriceString, objectToQueryString, convert, type, fetch } from '../../utils/utils'
import API from '../../common/API'
import category, { defaultItem, ORDER_BY } from '../../common/category'
const keys = Object.keys(category)
const categorys = keys.map(item => category[item])

const loadingLength = 20
const loadingStart = 0

let pageLength = loadingLength
let start = loadingStart
const ACTION_SHEET_LENGTH = 6

const page = {
  data: {
    list: [],
    indicatorDots: true, //设置是否显示面板指示点
    autoplay: true, //设置是否自动切换
    interval: 3000, //设置自动切换时间间隔,3s
    duration: 1000, //  设置滑动动画时长1s
    imgUrls: [
      "icon/1.jpg",
      "icon/2.jpg",
      "icon/3.jpg",
    ],

    scrollH: 0,
    load: true,
    imgWidth: 0,
    loadingCount: 0,
    images: [],
    col1: [],
    col2: [],
    //查找时需要使用的数据
    chooseBy: 0,
    /*relation:null,
    scene: undefined,
    category: undefined ,
    price: undefined,*/
    relation: [],
    scene: [],
    paraCategory: [],
    price: [],

    // 福利专场
    goodsWelfareItems: [

      /*{
        goodId: 0,
        name: '泊尔崖蜜蜜光面膜（5片盒装）',
      //  url: '../filter/filter',
        imageUrlMain: 'https://a3.vimage1.com/upload/merchandise/pdcvis/2017/08/21/142/fb2960bf8e074d029c24315279289c19-5_218x274_70.jpg',
        introduction:' 美妆不一之选',
        price: "86",
        oldPrice: "88",
      },
      {
        goodId: 1,
        name: '透无瑕矿物养护两用粉饼#03',
        //url: 'bill',
        imageUrlMain: 'http://img14.360buyimg.com/n0/jfs/t1/11856/12/3812/254106/5c22dc80Eb9db6077/5775bff48347af75.jpg',
        introduction: ' 美妆不二之选',
        newprice: "0",
        oldprice: "null",
      },*/

    ],

    categorys,


    // orderBy排序字段
    orderByActionSheetItems: [
      ORDER_BY.zonghe, // 综合排序
      ORDER_BY.latest, // 最新
      ORDER_BY.price_up_to_down, // 价格从高到低
      ORDER_BY.price_down_to_up // 价格从低到高
    ],
    // 当前默认是综合排序
    currentPX: 0
  },
  //到底
  onReachBottom: function () {
    var that = this;
    if (that.data.onReachBottom == true) {
      that.setData({
        isHideLoadMore: false
      })
    } else {
      that.setData({
        isHideLoadMore: true
      })
    }
    console.log('已到底部了哦！');
  }
  , goToDeatil: function (event) {
    // console.log(event)
    var id = event.currentTarget.dataset.id;
    // console.log(event.currentTarget.dataset.id)
    // console.log(event.currentTarget.dataset.url)
    //var url = event.currentTarget.dataset.url;
    /*wx.navigateTo({
     // url: '../filter/filter',
      url: url,
    })*/

    wx.navigateTo({ url: `../deatail/deatail?id=` + id })


  }
  //顶部选择框，当点击更多时，调用该函数
  , handleMoreTap(itemList, group) {
    // this.setData({currentIndex:index})
    wx.showActionSheet({
      itemList: itemList,
      success: res => {
        if (!res.cancel) {
          category[group].selectedIndex = ACTION_SHEET_LENGTH - 1 + res.tapIndex
          this.setData({ categorys })
          this.renderByDataFromServer(this.packageQueryParam())
        }
        this.setData({ currentIndex: -1 })
      }
    })
  }


  // 顶部tap操作 --start
  , switchSelectCond(e) {


    if (this.data.loading) return;
    console.log('顶部选择栏执行');

    const group = e.currentTarget.dataset.group //拿到name
    //console.log(group)
    const cat = category[group]//拿到category中的内容
    //console.log(cat)
    const index = keys.indexOf(group)//在categories数组中的下标
    //console.log(index)
    this.setData({
      currentIndex: index
    })
    /**
     * 数据处理，由于小程序action-sheet组件只允许最多有6个item，
     * 但现在我们的筛选条件基本上都超过6个，所以，需要对数据进行处理
     */
    //const len = ACTION_SHEET_LENGTH - 1
    const items = cat.items //拿到数组中的对应内容
    const sqlItems = cat.sqlItems
    const categoryObject = convert(items)
    //console.log(categoryObject+'  ob')
    //const itemList = items.slice(0, ACTION_SHEET_LENGTH) //分割数组
    //console.log(itemList)
    /*if(cat.name == 'price'){
      itemList.push('更多')
    }*/
    wx.showActionSheet({
      itemList: items,
      success: res => {
        const tapIndex = res.tapIndex //点击了哪一个下标
        console.log(tapIndex)
        /* if(tapIndex === len){
           // 点击了跟多
           this.handleMoreTap(items.slice(len), group)
         }else{
           console.log("whatfuck")
           if (!res.cancel) {
             cat.selectedIndex = tapIndex
             this.setData({ categorys })
             this.renderByDataFromServer(this.packageQueryParam())
           }
           this.setData({currentIndex:-1})
         }*/
        if (!res.cancel) {//不是取消
          cat.selectedIndex = tapIndex
          var selected = sqlItems[tapIndex]
          this.setData({ categorys })

          this.myaction(selected)
          //this.renderByDataFromServer(this.packageQueryParam())
        }
        this.setData({ currentIndex: -1 })

      }
    })
  },
  myaction: function (event) {
    console.log(event + "ASSSS")
    var that = this;
    that.setData({
      goodsWelfareItems: []
    })

  }
  // 顶部tap操作 --end
  , onLoad(query) {

    var that = this;
    that.setData({

      chooseBy: JSON.parse(query.queryParameter),
      load: true
    })
    console.log(query)
    that.setData({
      relation: that.data.relation.concat(that.data.chooseBy.relation),
      scene: that.data.scene.concat(that.data.chooseBy.scene),
      paraCategory: that.data.paraCategory.concat(that.data.chooseBy.category),
      price: that.data.price.concat(that.data.chooseBy.price)
    })
    /*console.log(that.data.relation)
    console.log(that.data.scene)
    console.log(that.data.paraCategory)*/


  

    //云开发连接数据库
    const db = wx.cloud.database({
      env: 'gift-test-2abb72' //环境ID
    })
    const _ = db.command;
    const wx_gift = db.collection('wx_gift')
    db.collection('wx_gift').field({
      type: true,
      _id: true,
      giftName: true,
      imageUrl: true,
      introduction: true,
      price: true,
      oldPrice: true,
      like: true
    }).where({
      "type.relation": _.in(that.data.relation),

      "type.scene": _.in(that.data.scene),
      "type.category": _.in(that.data.paraCategory)

    }).get({
        success(res) {
          var myjson = res.data;
          var str = [];
          //将json对象转换成数组对象
          for (var one in myjson) {
            var str = myjson[one];
            //  console.log(str);
            str.imageUrl = str.imageUrl[0];
            //加到数组中去
            that.setData({
              // list: myjson,
              goodsWelfareItems: that.data.goodsWelfareItems.concat(str)

            })
          }
        },
        fail(res) {
          console.log(res.data)
        },
        default(res) {
          console.log(res.data)
        }
      })





  }


  // 滚动到底部事件监听 -start
  , scrolltolower() {
    this.loadNewPage()
  }
  //触底调用事件
  , loadNewPage(goods = this.goods, isOrderBy = false) {
    console.log("到达底部");
  }

}
// 排序相关 end
Object.assign(page, common)
Page(page)

