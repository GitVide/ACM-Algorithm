const app = getApp()
import common from '../../common/app'
import {
    handleTitle,
    extractPriceFromPriceString,
    objectToQueryString,
    convert,
    type,
    fetch
} from '../../utils/utils'
import API from '../../common/API'
import category, {
    defaultItem,
    ORDER_BY
} from '../../common/category'
const keys = Object.keys(category)
const categorys = keys.map(item => category[item])


const loadingLength = 20
const loadingStart = 0

let pageLength = loadingLength
let start = loadingStart
const ACTION_SHEET_LENGTH = 6


Page({
    data: {
        load: true,
        indicatorDots: true, //设置是否显示面板指示点
        autoplay: true, //设置是否自动切换
        interval: 3000, //设置自动切换时间间隔,3s
        duration: 1000, //  设置滑动动画时长1s
        imgUrls: [
            "icon/1.jpg",
            "icon/2.jpg",
            "icon/3.jpg",
        ],

        scrollH: 0,
        imgWidth: 0,
        loadingCount: 0,
        images: [],
        col1: [],
        col2: [],


        giftId: null,
        //可以将最近喜欢的yem物品添加在该数组中，返回即可显示在页面
        //页面和筛选结果页面类似，可以改改，网上有一些现成的
        goodsWelfareItems: [
            //写死两个作为体现
            /* {
               goodId: 0,
               name: '泊尔崖蜜蜜光面膜（5片盒装）',
               //  url: '../filter/filter',
               imageUrlMain: 'https://a3.vimage1.com/upload/merchandise/pdcvis/2017/08/21/142/fb2960bf8e074d029c24315279289c19-5_218x274_70.jpg',
               introduction: ' 美妆不一之选',
               price: "86",
               oldPrice: "88",
             },
             {
               goodId: 1,
               name: '透无瑕矿物养护两用粉饼#03',
               //url: 'bill',
               imageUrlMain: 'http://img14.360buyimg.com/n0/jfs/t1/11856/12/3812/254106/5c22dc80Eb9db6077/5775bff48347af75.jpg',
               introduction: ' 美妆不二之选',
               price: "100",
               oldPrice: null,
             },*/
        ],


        // 当前默认是综合排序
        currentPX: 0

    },

    //到底
    onReachBottom: function() {
            var that = this;
            if (that.data.onReachBottom == true) {
                that.setData({
                    isHideLoadMore: false
                })
            } else {

                that.setData({
                    isHideLoadMore: true
                })
            }
            console.log('已到底部了哦！');
        }

        //逛一逛跳转
        ,
    favourite: function() {
            wx.navigateTo({
                url: '../gotogo/gotogo',
            })

        }


        ,
    goToDeatil: function(event) {
            var id = event.currentTarget.dataset.id;
            wx.navigateTo({
                url: `../deatail/deatail?id=` + id
            })
        }


        ,
    handleMoreTap(itemList, group) {
        // this.setData({currentIndex:index})
        wx.showActionSheet({
            itemList: itemList,
            success: res => {
                if (!res.cancel) {
                    category[group].selectedIndex = ACTION_SHEET_LENGTH - 1 + res.tapIndex
                    this.setData({
                        categorys
                    })
                    this.renderByDataFromServer(this.packageQueryParam())
                }
                this.setData({
                    currentIndex: -1
                })
            }
        })
    }


    // 顶部tap操作 --start
    ,
    switchSelectCond(e) {
        if (this.data.loading) return;
        console.log('switchSelectCond exec...');
        const group = e.currentTarget.dataset.group
        const cat = category[group]
        const index = keys.indexOf(group)
        this.setData({
            currentIndex: index
        })
        /**
         * 数据处理，由于小程序action-sheet组件只允许最多有6个item，
         * 但现在我们的筛选条件基本上都超过6个，所以，需要对数据进行处理
         */
        const len = ACTION_SHEET_LENGTH - 1
        const items = cat.items
        const categoryObject = convert(items)
        const itemList = items.slice(0, len)
        if (cat.name !== 'price') {
            itemList.push('更多')
        }
        wx.showActionSheet({
            itemList: itemList,
            success: res => {
                const tapIndex = res.tapIndex
                if (tapIndex === len) {
                    // 点击了跟多
                    this.handleMoreTap(items.slice(len), group)
                } else {
                    if (!res.cancel) {
                        cat.selectedIndex = tapIndex
                        this.setData({
                            categorys
                        })
                        this.renderByDataFromServer(this.packageQueryParam())
                    }
                    this.setData({
                        currentIndex: -1
                    })
                }
            }
        })
    }

    // 顶部tap操作 --end
    ,
    onLoad: function(query) {
            /*初始化完成后就调用云函数获取openid,获取完成后，
            使用getApp().globalData.openid即可获取用户openid*/
            wx.cloud.callFunction({
                name: 'login',
                data: {},
                success: res => {
                    console.log('[云函数] [login] user openid: ', res.result.openid)
                    app.globalData.openid = res.result.openid
                },
                fail: err => {
                    console.error('[云函数] [login] 调用失败', err)
                    wx.navigateTo({
                        url: '../deployFunctions/deployFunctions',
                    })
                }
            })

            var that = this

            console.log("开始")
            //云开发连接数据库
            const db = wx.cloud.database({
                env: 'gift-test-2abb72' //环境ID
            })
            const _ = db.command;
            const wx_gift = db.collection('wx_gift')
            wx_gift.field({
                _id: true,
                giftName: true,
                imageUrl: true,
                introduction: true,
                price: true,
                oldPrice: true,
                like: true
            }).get({
                success(res) {
                    console.log(res)
                    var myjson = res.data;
                    var str = [];
                    //将json对象转换成数组对象
                    for (var one in myjson) {
                        var str = myjson[one];
                        //  console.log(str);
                        str.imageUrl = str.imageUrl[0];
                        //加到数组中去
                        that.setData({
                            // list: myjson,
                            goodsWelfareItems: that.data.goodsWelfareItems.concat(str)

                        })
                    }
                },
                fail(res) {
                    console.log(res.data)
                },
                default (res) {
                    console.log(res.data)
                }
            })


        }
        // 滚动到底部事件监听 -start
        ,
    scrolltolower() {
        this.loadNewPage()
    },
    loadNewPage(goods = this.goods, isOrderBy = false) {
        if (!goods || goods.length === 0) return;
        const alreadyDisplay = this.data.goods || []
        //  如果是在 orderBy* 方法中调用的
        //  需要重置所有的条件
        if (isOrderBy) {
            alreadyDisplay.length = 0 // 清空已渲染数据，从新build数据并渲染
            this.setData({
                goods: []
            })
            pageLength = loadingLength
            start = loadingStart
        }
        const metas = alreadyDisplay.concat(goods.slice(start, start + pageLength))
        if (metas.length === goods.length) {
            //  当数据已经ready，但是页面还没有渲染出来
            //  就会马上出现“已经到底啦~”，为了防止这种情况，需要异步地设置 done 为 true
            setTimeout(() => {
                this.setData({
                    done: true
                })
            }, 120)
        } else {
            this.setData({
                done: false
            })
        }
        this.setData({
            goods: metas
        })
        this.goods = goods
        start += pageLength
    }
    // 滚动到底部事件监听 -end
    // ,search(){
    //   this.renderByDataFromServer(this.packageQueryParam())
    // }

    ,
    renderByDataFromServer(queryObject) {
        const url = `${API.giftq.url}/${objectToQueryString(queryObject)}`
        this.setData({
            loading: true
        })
        fetch({
            url,
            complete: () => {
                this.setData({
                    loading: false
                })
                this.setData({
                    load: true
                })
            }
        }).then(result => {
            console.log(`${url}返回的数据：`, result);
            // console.log(result);
            result = result.data
            const aids = result.aids
            // raiders 攻略
            let raiders = []
            // goods 单品
            let goods = []
            const reg = /http:\/\/|https:\/\//i
            const prefix = 'http://a.diaox2.com/cms/sites/default/files'

            for (let each of aids) {
                const [aid, type] = each
                const meta_info = result[`meta_infos_${type}`][aid]
                if (!meta_info) {
                    console.log('存在空的meta_info：')
                    continue
                }
                const {
                    ctype,
                    thumb_image_url
                } = meta_info

                if (thumb_image_url && !reg.test(thumb_image_url)) {
                    meta_info.thumb_image_url = `${prefix}/${thumb_image_url}`
                }

                meta_info.aid = aid
                meta_info.title = handleTitle(meta_info.title || meta_info.format_title)

                if (ctype == void 0) {
                    // console.log('SKU数据：', meta_info);
                    meta_info.price_num = extractPriceFromPriceString(meta_info.price)
                    const [pic] = meta_info.pics
                    meta_info.thumb_image_url = pic.url
                    goods.push(meta_info)
                } else if (ctype === 2) {
                    meta_info.price_num = extractPriceFromPriceString(meta_info.price)
                    goods.push(meta_info)
                } else if (ctype !== 2 && ctype !== 3) // 过滤掉专刊数据（ctype === 3）
                {
                    const rendered_keywords = meta_info.rendered_keywords
                    if (rendered_keywords) {
                        meta_info.rendered_keywords = rendered_keywords.map(keywords => keywords[0])
                    }
                    raiders.push(meta_info)
                }

            }

            // 在本地记录下所有攻略，以供查看“全部”
            wx.setStorage({
                key: "allRaiders",
                data: [...raiders]
            })
            // 攻略最多只有2篇
            if (raiders.length > 2) {
                raiders = raiders.slice(0, 2)
            }
            // console.log('攻略数据：', raiders);
            /**
             * 1. ctype不准  不是不准，是文章的ctype应该是2
             * 2. remove_aids数据不全
             * 3. 单品无price过滤掉
             *    price: 'N/A'
             */
            // 单品至少有2篇
            // 不足2篇，remove_aids来补
            if (goods.length < 2) {
                // 做一下非空判定
                // 鹏哲说如果全部命中，则remove_aids这个字段就没有值
                const aids = result.remove_aids || []
                // console.log(aids);
                for (let each of aids) {
                    const [aid, type] = each
                    const meta_info = result[`meta_infos_${type}`][aid]
                    // let meta_info = meta_infos[aid]
                    // if(!meta_info) continue
                    if (meta_info.ctype === 2) {
                        meta_info.price_num = extractPriceFromPriceString(meta_info.price)
                        goods.push(meta_info)
                    } else {
                        console.log('done else');
                    }
                }
            }
            this.loadNewPage(goods, true)
            // console.log('单品数据：', goods);
            this.setData({
                raiders,
                goods_copy: goods,
                currentPX: 0
            })
            wx.hideToast()
            // console.log(goods);
        }).catch(result => {
            console.log(`${API.giftq.url}接口错误：`, result)
            wx.hideToast()
        })
    }
})