// pages/myLove/myLove.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    giftId: null,
    //可以将最近喜欢的yem物品添加在该数组中，返回即可显示在页面
    //页面和筛选结果页面类似，可以改改，网上有一些现成的
    goodsWelfareItems: [
      //写死两个作为体现
      {
        goodId: 0,
        name: '泊尔崖蜜蜜光面膜（5片盒装）',
        //  url: '../filter/filter',
        imageUrlMain: 'https://a3.vimage1.com/upload/merchandise/pdcvis/2017/08/21/142/fb2960bf8e074d029c24315279289c19-5_218x274_70.jpg',
        introduction: ' 美妆不一之选',
        price: "86",
        oldPrice: "88",
      },
      {
        goodId: 1,
        name: '透无瑕矿物养护两用粉饼#03',
        //url: 'bill',
        imageUrlMain: 'http://img14.360buyimg.com/n0/jfs/t1/11856/12/3812/254106/5c22dc80Eb9db6077/5775bff48347af75.jpg',
        introduction: ' 美妆不二之选',
        price: "100",
        oldPrice: null,
      },
    ]

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //console.log(options.giftId);
    var that = this;
    this.setData({
      giftId: options.giftId // giftId即为主键id
    })
    /**
     * 实现添加逻辑
     */



    
  }
  , goToDeatil: function (event) {
    //去到详情页 类似于筛选结果页，写死的内容跳转后为null
    var id = event.currentTarget.dataset.id;
    wx.navigateTo({ url: `../deatail/deatail?id=` + id })
  },
})